#include <iostream>
#include "config.h"
#include "charmatrix.h"
#include "linked_list.h"
#include <vector>
#include <unistd.h> 
#include "dataset.h"
#include "instancecounter.h"
#include "priority_queue.h"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

vector<string> lex;
CharMatrix g_grid;
dataset g_dataset;
PriorityQueue g_priority_queue;


void fill_lexicon()
{
    while(true)
    {
        if (!config.quiet)
        {
            for (int i = 0; i < 5; i++)
            {
                cout << endl;
            }
            cout << "Please enter another word" << endl;
            cout << "> ";
        }
        string word;
        getline(cin, word);
        if (word.size() == 0)
        {
            break;
        }
        else if (word == "-")
        {
            lex.back();
            lex.pop_back();
        }
        else{
        lex.push_back(word);
        }
        if (!config.quiet)
        {
            cout << "So far, the words you have entered are:" << endl;
            int size = lex.size();
            for (int i = 0; i < size; i++)
            {
                cout << i << ". " << lex[i] << endl;
            }
        }
    }
}

void load_char_matrix()
{
    if (!config.quiet)
    {
        cout << "Please enter a grid of characters." << endl;
        cout << "All rows should have the same length." << endl;
        cout << "When you are done, just press Enter." << endl;
    }
    vector<string> grid;
    while(true)
    {
        string row;
        getline(cin, row);
        if (row.compare("") == 0)
            break;
        if (grid.size() > 0 && row.size() != grid[0].size())
            throw std::runtime_error("Rows in a CharMatrix must all have the same size!");
        grid.push_back(row);
    }
    int height = grid.size();
    int width = 0;
    if (height > 0)
        width = grid[0].size();
    g_grid.resize(width, height);
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            g_grid.put(x, y, grid[y][x]);
        }
    }
}

void print_char_matrix()
{
    for (int y = 0; y < g_grid.height(); y++)
    {
        for (int x = 0; x < g_grid.width(); x++)
        {
            cout << g_grid.get(x, y);
        }
        cout << endl;
    }
    cout << "CharMatrix has a width of " << g_grid.width() << " and a height of " << g_grid.height() << endl;
}

void fill(int x, int y, char c, int max_depth)
{
    
    if (config.debug)
    {
        usleep(100000);
        for (int i = 0; i < 20; i++)
            cout << endl;
        print_char_matrix();
        cout.flush();
    }
    char bef = g_grid.get(x, y);
    if (bef == c)
        return;
    g_grid.put(x, y, c);
    if (x > 0 && g_grid.get(x - 1, y) == bef)
        fill (x - 1, y, c, max_depth-1);
    if (y > 0 && g_grid.get(x, y - 1) == bef)
        fill (x, y - 1, c, max_depth-1);
    if (x + 1 < g_grid.width() && g_grid.get(x + 1, y) == bef)
        fill (x + 1, y, c, max_depth-1);
    if (y + 1 < g_grid.height() && g_grid.get(x, y + 1) == bef)
        fill (x, y + 1, c, max_depth-1);
}

void flood_fill()
{
    string word;
    cout << "Please enter a starting column:" << endl;
    cout << "> ";
    getline(cin, word);
    int x = stoi(word);
    cout << "Please enter a starting row:" << endl;
    cout << "> ";
    getline(cin, word);
    int y = stoi(word);
    cout << "Please enter a fill character:" << endl;
    cout << "> ";
    getline(cin, word);
    int c = word[0];
    cout << "Please enter the max fill depth:" << endl;
    cout << "> ";
    getline(cin, word);
    int max_depth = stoi(word);
    fill(x, y, c, max_depth);
}

bool does_occur(int x, int y, string& word, CharMatrix& used)
{
    if (word.length() == 0)
        return true;
    if (x<0)
        return false;
    if (y<0)
        return false;
    if (x>g_grid.width()-1)
        return false;
    if (y>g_grid.height()-1)
        return false;
    if (used.get(x,y) == 'x')
        return false;
    char c = word[0];
    if (c != g_grid.get(x,y))
        return false;

    string updatedWord = word.substr(1);
    used.put(x, y, 'x');

    bool found = false;
    if (does_occur(x, y+1, updatedWord, used))
        found = true;
    if (does_occur(x+1, y+1, updatedWord, used))
        found = true;
    if (does_occur(x+1, y, updatedWord, used))
        found = true;
    if (does_occur(x+1, y-1, updatedWord, used))
        found = true;
    if (does_occur(x, y-1, updatedWord, used))
        found = true;
    if (does_occur(x-1, y-1, updatedWord, used))
        found = true;
    if (does_occur(x-1, y, updatedWord, used))
        found = true;
    if (does_occur(x-1, y+1, updatedWord, used))
        found = true;
    return found;
}

void boggle()
{
    for (unsigned long n = 0; n < lex.size(); n++)
    {
        string& word = lex[n];
        CharMatrix used;
        used.resize(g_grid.width(), g_grid.height());
        for (int y = 0; y < g_grid.height(); y++)
        {
            for (int x = 0; x < g_grid.width(); x++)
            {
                if(does_occur(x, y, word, used))
                    cout << word << endl;
            }
        }
    }
}

void ll_unit_test()
{
    LinkedList list;

    // Test push_back and size
    list.push_back("one");
    list.push_back("two");
    list.push_back("three");

    list.pop_front();
    // if (list.size() != 3)
    //     throw std::runtime_error("Test failed: push_back or size");

    // // Test push_front
    // list.push_front("zero");
    // if (list.size() != 4)
    //     throw std::runtime_error("Test failed: push_front or size");
    // list.print(); // Expected output: zero one two three

    // // Test pop_front
    // list.pop_front();
    // if (list.size() != 3)
    //     throw std::runtime_error("Test failed: pop_front or size");
    // list.print(); // Expected output: one two three

    // // Test split
    // LinkedList other;
    // list.split(2, other);
    // list.print();
    // other.print();

    // std::cout << "Passed" << std::endl;
}

void merge_sort()
{
    LinkedList list_merge;
    for (long unsigned int i = 0; i < lex.size(); i++)
    {
        list_merge.push_back(lex[i]);
    }
    list_merge.sort();
    int i = 0;
    while(list_merge.size()>0)
    {
        lex[i] = list_merge.pop_front();
        i++;
    }
    std::cout << "comparisons: " << comparisons << std::endl;
}

void load_csv()
{
    cout << "Please enter a filename of a .csv file:" << endl;
    cout << "> ";
    string filename;
    getline(std::cin, filename);
    try {
        g_dataset.load_csv(filename);
    } catch (const std::exception& e) {
        cerr << "Error loading CSV file: " << e.what() << endl;
        return;
    }

    // Index the data
    g_dataset.index_data();
}

void query()
{
    // Ask for query parameters
    cout << "Please enter a column index:" << endl;
    cout << "> ";
    string column_str;
    getline(std::cin, column_str);
    int column = stoi(column_str);
    cout << "Please enter a starting value:" << endl;
    cout << "> ";
    string start;
    getline(std::cin, start);
    cout << "Please enter an ending value:" << endl;
    cout << "> ";
    string end;
    getline(std::cin, end);

    // Perform the query
    g_dataset.query(column, start, end);
}


void report()
{
    cout << "instantiated: " << g_instantiations << endl;
    cout << "deleted: " << g_deletions << endl;
}

void insert_into_priority_queue()
{
    cout << "Please enter a string:" << endl;
    cout << "> ";
    string value;
    getline(std::cin, value);
    g_priority_queue.insert(value);
}


void pop_first_from_priority_queue()
{
    string value = g_priority_queue.pop_first();
    cout << value << endl;
}


// Entry point
int main(int argc, char** argv)
{
    config.parse_flags(argc, argv);

    while (true)
    {
        for (int i = 0; i < 5; i++)
        {
            cout << endl;
        }
        cout << "Jay's PF2 projects" << endl << endl;
        cout << "Lexicon size: " << lex.size() << endl << endl;
        cout << "0. Quit" << endl;
        cout << "1. Fill lexicon" << endl;
        cout << "2. Tear Lexicon" << endl;
        cout << "3. Load char matrix" << endl;
        cout << "4. Print char matrix" << endl;
        cout << "5. Flood Fill" << endl;
        cout << "6. Boggle" << endl;
        cout << "7. Linked List unit test" << endl;
        cout << "8. Merge Sort" << endl;
        cout << "9. Load CSV file" << endl;
        cout << "10. Query" << endl;
        cout << "11. Memory report" << endl;
        cout << "14. Insert into priority queue" << endl;
        cout << "15. pop_first from priority queue" << endl;
        cout << "> ";
        
        string option;
        getline(cin, option);
        if (option.compare("0") == 0) {
            break;
        } else if (option.compare("1") == 0) {
            fill_lexicon();
        } else if(option.compare("2") == 0) {
            while (lex.size() > 0)
            {
                cout << lex.back() << endl;
                lex.pop_back();            
            }
        } else if (option.compare("3") == 0) {
            load_char_matrix();
        } else if (option.compare("4") == 0) {
            print_char_matrix();
        } else if (option.compare("5") == 0) {
            flood_fill();
        } else if (option.compare("6") == 0) {
            boggle();
        } else if (option.compare("7") == 0) {
            ll_unit_test();
            cout << "Seg fault after function?" << endl;
        } else if (option.compare("8") == 0) {
            merge_sort();
        } else if (option.compare("9") == 0) {
            load_csv();
        } else if (option.compare("10") == 0) {
            query();
        } else if (option.compare("11") == 0) {
            report();
        } else if (option.compare("14") == 0) {
            insert_into_priority_queue();

        } else if (option.compare("15") == 0) {
            pop_first_from_priority_queue();
        } else {
            cout << option << " was not one of the options. Quitting." << endl;
            break;
        }
    }
}
