#ifndef linked_list
#define linked_list

extern int comparisons;
#include "instancecounter.h"

class LinkedListNode : public Instancecounter
{
public:
    LinkedListNode* next;
    std::string value;
    LinkedListNode(std::string val);
    virtual ~LinkedListNode();
};

class LinkedList : public Instancecounter
{
protected:
    LinkedListNode* first;
    LinkedListNode* last;
    int length;

public:
    LinkedList();
    virtual ~LinkedList();
    void push_back(std::string s);
    void push_front(std::string s);
    string pop_front();
    int size();
    void split(int n, LinkedList& other);
    void print();
    void merge(LinkedList& other);
    void sort();
};

#endif
