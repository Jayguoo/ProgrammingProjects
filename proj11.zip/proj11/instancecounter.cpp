#include "instancecounter.h"
#include <fstream>
#include <algorithm>
#include <iostream>
#include <cstring>


int g_instantiations = 0;
int g_deletions = 0;


Instancecounter::Instancecounter()
{
    ++g_instantiations;
}


Instancecounter::~Instancecounter()
{
    ++g_deletions;
}
