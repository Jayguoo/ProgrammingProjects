#ifndef DATA_SET
#define DATA_SET


#include <string>
#include <vector>
#include "instancecounter.h"


using namespace std;
class dataset : public Instancecounter 
{
protected:
//   col name
vector< string > col_names;
//  matrix   row     cell
vector< vector< string > > data;
//  indxes  col-idx  pointer-to-row
vector< vector< vector<string>* > > indices;
public:
    dataset();
    ~dataset();
    void index_data();
    void load_csv(string& filename);
    int col_count();
    int row_count();
    int binary_search(string& target_val, int col_val);
    void query(int col, string& start, string& end);
    void print_row(int row, const std::vector<std::vector<std::string>*>& index);
    void print_index(int col_num);


};


#endif
