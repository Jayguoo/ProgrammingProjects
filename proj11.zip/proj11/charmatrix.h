#ifndef char_matrix
#define char_matrix

#include "instancecounter.h"



class CharMatrix : public Instancecounter 
{
    protected:
        std::vector<std::string> chars;




    public:
        CharMatrix();
        CharMatrix(CharMatrix& other);
        virtual ~CharMatrix();
        int height();
        int width();
        char get(int x, int y);
        void put(int x, int y, char c);
       


        void resize(int width, int height);
};


#endif
