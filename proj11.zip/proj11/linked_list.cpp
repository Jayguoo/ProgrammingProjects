#include <iostream>
#include <string>
#include <stdexcept>
#include "linked_list.h"
#include <cstring>

int comparisons;

int smart_compare(std::string& a, std::string& b) {
    // Skip the parts that are the same
    comparisons++;
    long unsigned int i = 0;
    while(i < a.size() && i < b.size() && a[i] == b[i]) {
        i++;
    }
    if (i >= a.size()) {
        if (i >= b.size()) {
            return 0;
        } else {
            // If a is a prefix of b, b comes after a
            return -1;
        }
    } else if (i >= b.size()) {
        // If b is a prefix of a, a comes after b
        return 1;
    }

    // Skip zeros
    long unsigned int a_start = i;
    long unsigned int b_start = i;
    while (a_start < a.size() && a[a_start] == '0')
        a_start++;
    while (b_start < b.size() && b[b_start] == '0')
        b_start++;

    // Count digits
    long unsigned int a_digits = a_start;
    while (a_digits < a.size() && a[a_digits] >= '0' && a[a_digits] <= '9')
        a_digits++;
    long unsigned int b_digits = b_start;
    while (b_digits < b.size() && b[b_digits] >= '0' && b[b_digits] <= '9')
        b_digits++;
    if (a_digits > 0 && a_digits < b_digits) {
        return -1; // a comes first because its number is shorter
    } else if (b_digits > 0 && b_digits < a_digits) {
        return 1; // b comes first because its number is shorter
    } else {
        // The numbers are the same length, so compare alphabetically
        return strcmp(a.c_str() + a_start, b.c_str() + b_start);
    }
}

// LinkedListNode Implementation
LinkedListNode::LinkedListNode(std::string val)
{
    this->next = nullptr;
    this->value = val;
}

LinkedListNode::~LinkedListNode()
{
    delete this->next;
}

// LinkedList Implementation
LinkedList::LinkedList()
{
    this->first = nullptr;
    this->last = nullptr;
    this->length =0;
}

LinkedList::~LinkedList()
{
    delete this->first;
}

void LinkedList::push_back(std::string s)
{
    LinkedListNode* new_node = new LinkedListNode(s);
    if (this->first)
    {
        if (!this->last)
            throw std::runtime_error("How is there a first, but no last?");
        this->last->next = new_node;
    }
    else
    {
        if (this->last)
            throw std::runtime_error("How is there a last, but no first?");
        this->first = new_node;
    }
    this->last = new_node;
    this->length++;
}

void LinkedList::push_front(std::string s)
{
    LinkedListNode* new_node = new LinkedListNode(s);
    new_node->next = this->first;
    this->first = new_node;
    if (!this->last)
        this->last = new_node;
    this->length++;
}

std::string LinkedList::pop_front()
{
    if (!this->first)
        throw std::runtime_error("Cannot pop from an empty list");
    std::string temp_value= first->value;
    LinkedListNode* temp = this->first;
    this->first = first->next;
    temp->next = nullptr;
    this->length--;

    if (!this->first)
        this->last = nullptr;

    delete temp;
    return temp_value;
}

int LinkedList::size()
{
    return this->length;
}

void LinkedList::split(int n, LinkedList& other)
{
    for(int i = 0; i < n; i++)
    {
        other.push_back(pop_front());
    }
}


void LinkedList::print() {
    LinkedListNode* current = this->first;
    while (current) {
        std::cout << current->value << " ";
        if (current->next) {
            current = current->next;
        } else {
            break;
        }
    }
    std::cout << std::endl;
}


void LinkedList::merge(LinkedList& other)
{
    LinkedList mergedList;
    while(this->length > 0 || other.size() > 0)
    {
        if (this->length > 0 && other.size() > 0)
        {
            int cmp = smart_compare(this->first->value,other.first->value);
            if(cmp < 0)
            {
                mergedList.push_back(pop_front());
                //pop_front();
            }
            else if (cmp > 0)
            {
                mergedList.push_back(other.first->value);
                other.pop_front();
            }
            else
            {
                mergedList.push_back(this->first->value);
                pop_front();
            }
        }
        else if (this->length > 0)
        {
            mergedList.push_back(this->first->value);
            pop_front();
        }
        else
        {
            mergedList.push_back(other.first->value);
            other.pop_front();
        }
    }
    while(mergedList.size() > 0)
    {
        push_back(mergedList.pop_front());
    }
}

void LinkedList::sort()
{
    if (this->size() < 2)
        return;
    LinkedList that;
    this->split(this->size()/2, that);
    this->sort();
    that.sort();
    this->merge(that);
}

