#ifndef config_h
#define config_h
#include <string>




// Declare a Config class
class Config
{
public:

    bool debug;
    bool quiet;

    Config();

    virtual ~Config();

    void parse_flags(int argc, char** argv);
};


extern Config config;


void log(const std::string&);




#endif
