#include "priority_queue.h"
#include "linked_list.h"

#include <iostream>
#include <string>
#include <stdexcept>
#include <cstring>

PriorityQueue::PriorityQueue()
{
    this->Prior.push_back("");
}

PriorityQueue::~PriorityQueue()
{

}

void PriorityQueue::insert(const std::string& value) {
    Prior.push_back(value);
    swim(Prior.size() - 1);
}

std::string PriorityQueue::pop_first() {
    if (Prior.size() <= 1) {
        throw std::out_of_range("Priority queue is empty");
    }

    std::string top = Prior[1];
    Prior[1] = Prior.back();
    Prior.pop_back();
    sink(1);

    return top;
}

bool PriorityQueue::empty() const {
    return Prior.size() <= 1;
}

void PriorityQueue::swim(int index) {
    while (index > 1 && smart_compare(Prior[index], Prior[index / 2])) {
        std::swap(Prior[index], Prior[index / 2]);
        index /= 2;
    }
}

void PriorityQueue::sink(long unsigned int index) {
    while (2 * index < Prior.size()) {
        long unsigned int child = 2 * index;
        if (child < Prior.size() - 1 && smart_compare(Prior[child + 1], Prior[child])) {
            child++;
        }
        if (!smart_compare(Prior[child], Prior[index])) {
            break;
        }
        std::swap(Prior[child], Prior[index]);
        index = child;
    }
}

bool PriorityQueue::smart_compare(const std::string& a, const std::string& b) {
    return a < b; // Comparing strings based on their default ordering (lexicographical order)
}