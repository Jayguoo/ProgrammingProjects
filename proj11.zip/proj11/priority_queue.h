#ifndef priority_queue
#define priority_queue

#include <vector>
#include <string>

class PriorityQueue {
protected:
    std::vector<std::string>  Prior;

    void swim(int index);
    void sink(long unsigned int index);
    static bool smart_compare(const std::string& a, const std::string& b);

public:
    PriorityQueue();
    virtual ~PriorityQueue();
    void insert(const std::string& value);
    std::string pop_first();
    bool empty() const;
};




#endif 