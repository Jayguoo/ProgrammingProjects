#include "dataset.h"
#include <fstream>
#include <algorithm>
#include <iostream>
#include <cstring>

int active_column = 0;


dataset::dataset()
{
}


dataset::~dataset()
{
}


int scmp(std::string& a, std::string& b) {
    // Skip the parts that are the same
    long unsigned int i = 0;
    while(i < a.size() && i < b.size() && a[i] == b[i]) {
        i++;
    }
    if (i >= a.size()) {
        if (i >= b.size()) {
            return 0;
        } else {
            return -1;
        }
    } else if (i >= b.size()) {
        return 1;
    }


    // Skip zeros
    long unsigned int a_start = i;
    long unsigned int b_start = i;
    while (a_start < a.size() && a[a_start] == '0')
        a_start++;
    while (b_start < b.size() && b[b_start] == '0')
        b_start++;


    // Count digits
    long unsigned int a_digits = a_start;
    while (a_digits < a.size() && a[a_digits] >= '0' && a[a_digits] <= '9')
        a_digits++;
    long unsigned int b_digits = b_start;
    while (b_digits < b.size() && b[b_digits] >= '0' && b[b_digits] <= '9')
        b_digits++;
    if (a_digits > 0 && a_digits < b_digits) {
        return -1; // a comes first because its number is shorter
    } else if (b_digits > 0 && b_digits < a_digits) {
        return 1; // b comes first because its number is shorter
    } else {
        // The numbers are the same length, so compare alphabetically
        return strcmp(a.c_str() + a_start, b.c_str() + b_start);
    }
}


string& strip( string& value)
{
    string& s = value;
    while(s.size() > 0 && std::isspace(s[s.size() - 1 ]))
        s.erase(s.end() - 1);
    while(s.size() > 0 && std::isspace(s[0]))
        s.erase(s.begin());
    return s;
}


bool custom_less(vector<string>* a, vector<string>* b)
{
    string val_a = strip((*a)[active_column]);
    string val_b = strip ((*b)[active_column]);
    return (scmp(val_a, val_b) < 1);
}


void dataset::load_csv(string& filename)
{
    // Clear any existing data
    this->data.clear();


    // Open the file
    std::ifstream stream;
    stream.open(filename);
    if (!stream.is_open()) {
        throw std::system_error(errno, std::generic_category(), filename);
    }


    // Read the file
    while (!stream.eof())
    {
        // Read a line
        string s;
        if (!std::getline(stream, s))
            break;
        vector<string> empty;
        this->data.push_back(empty);
        vector<string>& current_row = this->data.back();


        // Break up the line into cells
        while (true)
        {
            // Find the next comma
            size_t pos = s.find(",");
            if (pos == std::string::npos)
            {
                // This is the last cell in the row
                current_row.push_back(s);
                break;
            }
            else
            {
                // This is not the last cell in the row
                current_row.push_back(s.substr(0, pos));
                s.erase(0, pos + 1); // erase the cell and the comma
            }
        }


        // Ensure all rows have the same size
        if (current_row.size() < 1)
        {
            // This row is empty, so just drop it
            this->data.pop_back();
        }
        else if (current_row.size() != this->data[0].size())
        {
            // Uh oh, the row is the wrong size!
            string s = "Error, row " + this->data.size();
            s += " has " + current_row.size();
            s += " elements. Expected " + this->data[0].size();
            throw std::runtime_error(s);
        }
    }


    // Move the first row into this->col_names
    this->col_names = this->data[0];
    this->data.erase(this->data.begin());
}


void dataset::index_data()
{
    // Index the data
    indices.clear();
    indices.resize(this->col_count());
    for (int i = 0; i < this->col_count(); i++)
    {
        // Build an index for column i
        vector< vector<string>* >& index = indices[i];
        for (int j = 0; j < this->row_count(); j++)
            index.push_back(&this->data[j]);


        // Sort the index in column i using smart_compare
        // *** you have to write this part ***
        active_column = i;
        std::sort(index.begin(), index.end(), custom_less);
    }
}




int dataset::col_count()
{
      if (row_count() == 0)
        return 0;
    return this->data[0].size();
}


int dataset::row_count()
{
    return this->data.size();


}




void dataset::print_row(int row, const std::vector<std::vector<std::string>*>& index)
{
    std::vector<std::string>* the_row = index[row];
    for (size_t i = 0; i < the_row->size(); i++)
    {
        if (i > 0)
            std::cout << ", ";
        std::cout << (*the_row)[i];
    }
    std::cout << std::endl;
}


int dataset::binary_search(string& target_val, int col_num)
{
   
    vector< vector<string>*> index = this->indices[col_num];
    unsigned int floor = 0;
    unsigned int ceil = this->row_count();
    unsigned int row_num;
    while(true)
    {
        row_num =(floor + ceil)/2;
        if (row_num == floor)
          break;
        vector<string>& row = *index[row_num];
        int cmp = scmp(target_val, row[col_num]);
        if (cmp < 0 )
            floor = row_num;
        else    
            ceil = row_num;
    }
    while (row_num > 0 && (*indices[col_num][row_num])[col_num] >= target_val) {
        row_num--;
    }
    while (row_num < data.size() && (*indices[col_num][row_num])[col_num] < target_val) {
        row_num++;
    }
    return row_num;
    }




void dataset::query(int col, string& start, string& end)
{
    vector< vector<string>*>& index = this->indices[col];
    unsigned int row = binary_search(start, col);
    while(row < (unsigned int)index.size())
    {
        if (row >= index.size())
            break;
         vector<string>* the_row = index[row];
       if (scmp(end, (strip((*the_row)[col]))) == 0) {
        break;
        }
    print_row(row, index);
    row++;
    }
}


void dataset::print_index(int col_num)
{
    cout << "Sorted by column " << col_num << ":" << endl;
    cout << "-------------------" << endl;
    vector< vector<string>*> index = this->indices[col_num];
    for (size_t i = 0; i < index.size(); i++)
    {
        vector<string>& row = *index[i];
        for (size_t j = 0; j < row.size(); j++)
        {
            if (j > 0)
                cout << ", ";
            cout << row[j];
        }
        cout << endl;
    }
}
