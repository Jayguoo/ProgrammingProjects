#ifndef instancecounter_h
#define instancecounter_h






#include <string>
#include <vector>
#include <iostream>




using namespace std;

extern int g_instantiations;
extern int g_deletions;
class Instancecounter
{
    public:
        Instancecounter();
        virtual ~Instancecounter();









};


#endif
