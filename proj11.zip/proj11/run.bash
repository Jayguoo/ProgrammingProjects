#!/bin/bash
set -e
g++ -Wall -Werror main.cpp config.cpp charmatrix.cpp linked_list.cpp dataset.cpp instancecounter.cpp priority_queue.cpp -o lex
./lex $*
