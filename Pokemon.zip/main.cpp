/******************************************************************************
Fall 2023 Programming Foundations I
Author: STUDENT NAME
Date: November ???, 2023
Purpose: 
*******************************************************************************/

#include "Trainer.h"


//wild Pokemon (read in from a file) list size
const int WILD_POKEMON_LIST_SIZE = 25;

//error checking for input of y or n
char charInputCheck()
{
	char input;
		cout << ">> "; cin >> input;
		while(input != 'y' && input != 'n')
		{
			   cout << "Please enter either 'y' or 'n'.\n>> ";
			   cin >> input;
		}
	return input;
}


//given - generate both a wild Pokemon and an item
void generateEncounter(string pokeList[], string &encounteredPokemon, string &pickedUpItem)
{
	srand(time(NULL));
	int randomNum = rand() % WILD_POKEMON_LIST_SIZE;
	encounteredPokemon = pokeList[randomNum];
	
	randomNum = rand() % Trainer::INVENTORY_MAX;
	switch(randomNum)
	{
		case 0: 
			pickedUpItem = "Poke Ball";
			break;
		case 1: 
			pickedUpItem = "Ultra Ball";
			break;
		case 2: 
			pickedUpItem = "Potion";
			break;
		default: 
			pickedUpItem = "Poke Ball";
	}
}

//readFile
void readFile(string pokemonList[], string fileName)
{
    string name;
    
    ifstream din;
    din.open(fileName);
    if (din.fail())
    {
        cout << "error bad thing\n";
        return;
    }
    int i = 0;
    while(getline(din,name))
    {
        pokemonList[i] = name;
        i++;
    }
    din.close();
    return;
}
    

int main() 
{
	string wildPokemon = "";
	string item = "";
	bool stillPlaying = true;
	char input = 'a';
	string currPokemon = "";
	string pokemonList[WILD_POKEMON_LIST_SIZE];


	//uncomment each of the tests as you finish writing the code in Trainer.cpp
	cout << "Testing readFile()...\n" << endl;
	readFile(pokemonList, "PokemonList.txt");

	cout << "Testing default constructor..." << endl;
	Trainer player;
	player.printStats();

	cout << "Testing parameterized constructor..." << endl;
	Trainer brock("Brock", "Diglett");
	brock.printStats();

	cout << "Testing copy constructor..." << endl;
	Trainer brock2(brock);
	brock2.printStats();

	cout << "Testing setName()..." << endl;
	player.setName("Ash");
	player.printStats();

	cout << "Testing addPokemon()..." << endl;
	player.addPokemon("Pikachu");
	player.printStats();

	cout << "Testing addItem()..." << endl;
	player.addItem(Trainer::POKE_BALL);
	player.addItem(Trainer::ULTRA_BALL);
	player.addItem(Trainer::POTION);
	player.printStats();

	cout << "Testing generateEncounter()..." << endl;
	generateEncounter(pokemonList, wildPokemon, item);
	cout << "wildPokemon: " << wildPokemon << endl;
	cout << "item: " << item << endl;
	cout << endl;

	cout << "Testing generateEncounter()..." << endl;
	generateEncounter(pokemonList, wildPokemon, item);
	cout << "wildPokemon: " << wildPokemon << endl;
	cout << "item: " << item << endl;
	cout << endl;

	cout << "Game loop starting..." << endl;
	while(stillPlaying)
	{
		//generate an encounter to get the random item and the wild Pokemon
        generateEncounter(pokemonList, wildPokemon, item);
		
		
		//fulfill item encounter
        if (item == "Poke Ball" || item == "Ultra Ball" || item == "Potion")
        {
            cout << "You found a(n) " << item << "! Do you want to keep it? y/n\n";
            input = charInputCheck();
            
            if (input == 'y')
            {
                if (item == "Poke Ball")
                {
                	player.addItem(Trainer::POKE_BALL);
                }
                else if (item == "Ultra Ball")
                {
                    player.addItem(Trainer::ULTRA_BALL);
                }
                else
                {
                	player.addItem(Trainer::POTION);
                }
            }
            else
            {
                cout << "You chose not to keep the " << item << ".\n";
            }
        }
        else
        {
            cout << "Unknown item encountered!\n";
        }



		//print stats
        player.printStats();
		

		//generate steps
		int numSteps = rand() % 10 + 1;
		for (int i = 1; i <= numSteps; i++)
		{ 
			if(numSteps == 1)
				cout << "You've taken 1 step.\n";
			else
				cout << "You've taken " << i << " steps." << endl;
		}

		//fulfill Pokemon encounter
        cout << "You encountered a(n) " << wildPokemon << "!\nDo you want to fight it? y/n\n";		
		input = charInputCheck();

        if (input == 'y')
        {
            cout << "Which Pokemon do you want to use?\n";

            for (int i = 0; i < player.getNumPokemon(); ++i)
            {
                cout << i + 1 << ") " << player.getPokemon(i) << "\n";
            }
            
            int pick;
            
            cin >> pick;

            int fight = rand() % 2 + 1;
    
            bool catchAttemptResult = (fight > 1);

            if (catchAttemptResult)
            {
            cout << "You and " << player.getPokemon(pick - 1) << " won! Do you want to catch the " << wildPokemon <<"?\n";
            input = charInputCheck();
                if (input == 'y' && (Trainer::POKE_BALL > 0 || Trainer::ULTRA_BALL > 0))
                {
                    cout << "1) Poke Ball ("<< player.getItemAmount(Trainer::POKE_BALL) <<" remaining)\n2) Ultra Ball (" << player.getItemAmount(Trainer::ULTRA_BALL) << " remaining)\n";
                    cin >> pick;
                    if(pick == 1)
                    {
                        cout << "You successfully caught the wild " << wildPokemon << "!\n";
                        player.addPokemon(wildPokemon);
                        player.useItem(Trainer::POKE_BALL);
                    }
                    else if (pick == 2)
                    {
                        cout << "You successfully caught the wild " << wildPokemon << "!\n";
                        player.addPokemon(wildPokemon);
                        player.useItem(Trainer::ULTRA_BALL);
                    }
                    else 
                    {
                        cout << "n/a.\n";
                    }
                }
            }
            
        else
        {
            cout << "Oh no! " << player.getPokemon(pick - 1) << " fainted and the " << wildPokemon << " escaped! Use a Potion? y/n\n";
            

            if (Trainer::POTION == 0)
            {
                player.removePokemon(pick - 1);
                cout << player.getPokemon(pick - 1) << " was transferred to Professor Oak\n";
            }
            else 
            {

                input = charInputCheck();
                if (input == 'y')
                {
                
                    player.useItem(Trainer::POTION);
                    cout << player.getPokemon(pick - 1) << " was healed. " << player.getItemAmount(Trainer::POTION) << " potion(s) remaining";
                }
                else 
                {
                    player.removePokemon(pick - 1);
                    cout << player.getPokemon(pick - 1) << " was transferred to Professor Oak\n";
                }
            }
            
        }

    // Update player's stats
        player.printStats();
        }
        else
        {
            cout << "You chose not to catch the wild " << wildPokemon << ".\n";
        }
		

		//check if user can still play, and then if they want to still play
		// if the user has no pokemon, they can't keep playing
        if (player.getNumPokemon() == 0)
        {
            cout << "You have no Pokemon left. Game over!\n";
            stillPlaying = false;
        }
		//else, see if the user wants to keep playing

        else
        {
			//note that these 4 lines will likely be inside of an if/else block that is detailed 
			//at the end of 2. Description in the homework
			cout << "Do you want to keep playing?" << endl;
			input = charInputCheck();

			if (input == 'n')
				stillPlaying = false;
        }
	}
	//create a unique filename with number of seconds passed since Jan 1, 1970 so multiple
	//runs of the program will save to different files
	string outputFilename = "player-";
	outputFilename.append(std::to_string(time(0)));
	outputFilename.append(".txt");

	//save to file
	player.writeFile(outputFilename);
	

	cout << "Your player information has been saved to " << outputFilename << ". Until next time!\n";
	return 0;
}
