#!/bin/bash
set -e
javac Main.java View.java Controller.java json.java Model.java point.java
java Main
