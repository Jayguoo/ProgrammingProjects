

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import javax.swing.JButton;
import java.awt.Color;


class View extends JPanel
{


    JButton save_button;
    JButton load_button;


    BufferedImage[] item_images;
    Model model;


    int time;
    int horizontalScroll;
    int verticalScroll;


    View(Model m)
    {
        this.model = m;
        this.time = 0;


        //intialize a default value for horizontal and vertical scroll
        this.horizontalScroll = 100;
        this.verticalScroll = 100;


        // Make load and save buttons
        this.save_button = new JButton("Save");
        this.add(save_button);


        this.load_button = new JButton("Load");
        this.add(load_button);


        this.save_button.setFocusable(false);
        this.load_button.setFocusable(false);


        // Load the images
        this.item_images = new BufferedImage[Main.MapItemTypes.length];
        for (int i = 0; i < Main.MapItemTypes.length; i++) {
            BufferedImage image = null;


            //if image fails to load, throw an error
            try
            {
                image = ImageIO.read(new File("images/" + Main.MapItemTypes[i] + ".png"));
            } catch(Exception e) {
                e.printStackTrace(System.err);
                System.exit(1);
            }
            this.item_images[i] = image;
        }
    }
    public void paintComponent(Graphics g)
    {




        this.time++;


        // Clear the background
        g.setColor(new Color(64, 255, 128));
        g.fillRect(0, 0, this.getWidth(), this.getHeight());




        //Draw purple square in top right corner
        g.setColor(new Color(198, 21, 230));
        g.fillRect(0, 0, 200, 200);


        //Draw the currently selected image in the top-left corner
        BufferedImage image = this.item_images[model.current_item];
        g.drawImage(image, 30, 0, null);


        // Draw all the item images
        for (int i = 0; i < model.items.size(); i++) {


            MapItem item = model.items.get(i);
            point p = item.pos(this.time);
            image = this.item_images[item.type];
            int w = image.getWidth();
            int h = image.getHeight();


            // Draw the image with the bottom center at (x, y)
        if (item.type == 2) {
            // Constants for amplitude and frequency
            double amplitude = 50;  
            double frequency = 2 * Math.PI / 30;  
   
            // Calculate the current scale based on the sine wave function
            double scaleFactor = 1 + (amplitude/100) * Math.sin((double)time * frequency);
            // Calculate the width and height of the scaled image
            int scaledWidth = (int) (w * scaleFactor);
            //int scaledHeight = (int)(h * Math.max(1,scaleFactor));
            int scaledHeight = (int)(h * scaleFactor);




            // Calculate the new position to keep the image centered
            int x = p.x -scaledWidth / 2 - this.horizontalScroll;
            int y = p.y  -scaledHeight- this.verticalScroll;
   
            // Draw the scaled image
            g.drawImage(image,x, y, x +scaledWidth ,y + scaledHeight,0,0, w, h
            ,null);
        }
     else if (item.type != 2)
         g.drawImage(image, p.x - w / 2 - this.horizontalScroll, p.y - h - this.verticalScroll, null);




    }
    }




}
