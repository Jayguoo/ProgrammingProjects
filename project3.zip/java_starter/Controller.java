

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;


class Controller implements MouseListener, KeyListener, ActionListener
{
    View view;
    Model model;
   
    boolean keyLeft;
    boolean keyRight;
    boolean keyUp;
    boolean keyDown;


    Controller(Model m, View v)
    {
        this.model = m;
        this.view = v;
        this.view.addMouseListener(this);
        this.view.save_button.addActionListener(this);
        this.view.load_button.addActionListener(this);
    }


    public void mousePressed(MouseEvent e)
    {
        //see if the user left clicked
        if(e.getButton() == 1) {
            this.model.setDestination(e.getX(), e.getY());


            //see if the user left clicked within the purple box
            if (e.getX() < 200 && e.getY() < 200) {


                //if so, change the item selected
                this.model.changeItem();
                return;
            }


            //otherwise, add the item to the model, and convert view coords to model coords
            this.model.addItem((e.getX() + this.view.horizontalScroll), (e.getY() + this.view.verticalScroll));
        }


        //see if the user right clicked
        if(e.getButton() == 3) {


            if(this.model.items.size() == 0) {
                return;
            }


            if(this.model.items.size() == 1) {
                this.model.items.clear();
                return;
            }


            double shortest;
            int shortestPos = 0;
            double tempDist;
            double itemXValue = (double) this.model.items.get(0).getItemX();
            double itemYValue = (double) this.model.items.get(0).getItemY();


            shortest = calcDistance(e.getX(), e.getY(), itemXValue, itemYValue);


            for(int i = 1; i < this.model.items.size(); i++) {


                itemXValue = (double) this.model.items.get(i).getItemX();
                itemYValue = (double) this.model.items.get(i).getItemY();


                tempDist = calcDistance(e.getX(), e.getY(), itemXValue, itemYValue);


                //if a MapItem is closer, then change shortest and shortestPos accordingly
                if(tempDist < shortest) {


                    shortest = tempDist;
                    shortestPos = i;
                }
            }
            //remove the item from the array
            this.model.removeItem(shortestPos);
            return;
        }


    }


    public void mouseReleased(MouseEvent e)
    {   }
   
    public void mouseEntered(MouseEvent e)
    {   }
   
    public void mouseExited(MouseEvent e)
    {   }
   
    public void mouseClicked(MouseEvent e)
    {   }
   
    public void keyPressed(KeyEvent e)
    {
        switch(e.getKeyCode())
        {
            case KeyEvent.VK_RIGHT:
                this.keyRight = true;
                break;
            case KeyEvent.VK_LEFT:
                this.keyLeft = true;
                break;
            case KeyEvent.VK_UP:
                this.keyUp = true;
                break;
            case KeyEvent.VK_DOWN:
                this.keyDown = true;
                break;
            case KeyEvent.VK_D:
                this.keyRight = true;
                break;
            case KeyEvent.VK_A:
                this.keyLeft = true;
                break;
            case KeyEvent.VK_W:
                this.keyUp = true;
                break;
            case KeyEvent.VK_S:
                this.keyDown = true;
                break;
        }
    }


    public void keyReleased(KeyEvent e)
    {
        switch(e.getKeyCode())
        {
            case KeyEvent.VK_RIGHT:
                this.keyRight = false;
                break;
            case KeyEvent.VK_LEFT:
                this.keyLeft = false;
                break;
            case KeyEvent.VK_UP:
                this.keyUp = false;
                break;
            case KeyEvent.VK_DOWN:
                this.keyDown = false;
                break;
            case KeyEvent.VK_D:
                this.keyRight = false;
                break;
            case KeyEvent.VK_A:
                this.keyLeft = false;
                break;
            case KeyEvent.VK_W:
                this.keyUp = false;
                break;
            case KeyEvent.VK_S:
                this.keyDown = false;
                break;
            case KeyEvent.VK_ESCAPE:
                System.exit(0);
        }
        char c = Character.toLowerCase(e.getKeyChar());
        if(c == 'q')
            System.exit(0);
        if(c == 'r')
            this.model.reset();
    }


    public void keyTyped(KeyEvent e)
    {   }


    void update()
    {
        if(this.keyRight) {
            this.view.horizontalScroll = this.view.horizontalScroll + 35;
        }
        if(this.keyLeft) {
            this.view.horizontalScroll = this.view.horizontalScroll - 35;
        }if(this.keyDown) {
            this.view.verticalScroll = this.view.verticalScroll + 35;
        }if(this.keyUp) {
            this.view.verticalScroll = this.view.verticalScroll - 35;
        }
    }
    public void actionPerformed(ActionEvent e)
    {




        if(e.getSource() == this.view.save_button)
        {
            try {
                FileWriter writer = new FileWriter("map.json");
                writer.write(this.model.marshal().toString());
                writer.close();
            } catch (IOException exception) {
                exception.printStackTrace();
                System.exit(1);
            }
        }
        //unmarshall all map items if load button is pushed
        else if (e.getSource() == this.view.load_button)
        {
           
            try {
                String content = new String(Files.readAllBytes(Paths.get("map.json")));
                Json map = Json.parse(content);
                this.model.unmarshal(map);
            } catch (IOException exception) {
                exception.printStackTrace();
                System.exit(1);
            }
           
        } else {
            throw new RuntimeException("An unrecognized button was pushed");
        }


    }




    //calculates the distance between the cursor and the specified map item
    public double calcDistance(double mouseX, double mouseY, double itemX, double itemY) {


        double deltaX = mouseX - (itemX - this.view.horizontalScroll);
        double deltaY = mouseY - (itemY - this.view.verticalScroll);
        double hyp = Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));


        return hyp;
 
    }




}


