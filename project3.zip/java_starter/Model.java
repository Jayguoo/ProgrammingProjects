

import java.util.ArrayList;
import java.util.Comparator;
import java.lang.Math;


class Model
{
    View view;
    int cursor_x;
    int cursor_y;
    public int current_item;


    ArrayList<MapItem> items;
    ItemYComparator ItemYComp;


    Model()
    {
        this.view = null;
        this.cursor_x = 150;
        this.cursor_y = 100;
        this.current_item = 0;
        this.items = new ArrayList();
        this.ItemYComp = new ItemYComparator();
    }


    public void setView(View v) {


        this.view = v;
    }


    public void update()
    {
    //  int time = (int) (System.currentTimeMillis() / 100); // Adjust this divisor to control the speed
    // for (int i = 0; i < this.items.size(); i++)
    // {
    //     MapItem item = this.items.get(i);


    //     if (item instanceof Jumper) {
    //         // Update the position of the jumper based on time
    //         this.items.set(i, item.pos(time));
    //     }
    // }
    }


    public void reset()
    {
        this.items.clear();
        this.view.horizontalScroll = 100;
        this.view.verticalScroll = 100;
    }




    public void setDestination(int x, int y)
    {
        this.cursor_x = x;
        this.cursor_y = y;
    }


    //called when the user left clicks to add an item onto the map
    public void addItem(int x, int y) {




        this.items.add(MapItem.newItem(x, y, this.current_item));
        this.items.sort(this.ItemYComp);
        return;
    }
    public void removeItem(int pos) {
        this.items.remove(pos);
        return;
    }


    public void changeItem() {
        if(this.current_item + 1 >= Main.MapItemTypes.length) {
            this.current_item = 0;
            return;
        }
       
       
        this.current_item++;


    }
    public Json marshal() {


        Json map = Json.newObject();
        Json list_of_map_items = Json.newList();
        map.add("xscroll", this.view.horizontalScroll);
        map.add("yscroll", this.view.verticalScroll);
        map.add("items", list_of_map_items);


        for (int i = 0; i < this.items.size(); i++)
        {
            list_of_map_items.add(this.items.get(i).marshal());
        }


        return map;
    }


    //turn all the objects in map.json into MapItem objects and places the into the "items" array list
    public void unmarshal(Json map) {


        //retrieve the horizontal and vertical scroll posistions
        this.view.horizontalScroll = map.getInt("xscroll");
        this.view.verticalScroll = map.getInt("yscroll");


        //clear all items on the current map
        this.items.clear();


        Json tmpList = map.get("items");


        //retrieve each item in the json map and add to the items array list accordingly
        for(int i = 0; i < tmpList.size(); i++) {
            this.items.add(unmarshallMapItem(tmpList.get(i)));
        }


    }
   
    public static MapItem unmarshallMapItem(Json ob) {
        //have the objects keep moving after loading
        int type = (int) ob.getLong("type");


        if (type == 3 || type == 9)
        {
            return new Jumper((int) ob.getLong("x"), (int) ob.getLong("y"), (int)ob.getLong("type"));
        }
        else if (type == 4 || type == 7)
        {
            return new Strafer((int) ob.getLong("x"), (int) ob.getLong("y"), (int)ob.getLong("type"));
        }
        else
        {
            return new MapItem((int)ob.getLong("x"), (int)ob.getLong("y"), (int)ob.getLong("type"));


        }




    }


}


class MapItem
{
    protected int x;
    protected int y;
    public int type;


    protected MapItem(int x, int y, int type)
    {
        this.x = x;
        this.y = y;
        this.type = type;
    }
    public int getItemX() {
        return this.x;
    }


    public int getItemY() {
        return this.y;
    }


    public Json marshal() {


        Json temp = Json.newObject();
        temp.add("x", this.x);
        temp.add("y", this.y);  
        temp.add("type", this.type);


    return temp;


    }


    point pos(int time)
    {
        return new point(this.x, this.y);
    }


    public static MapItem newItem(int x, int y, int type) {
        if (type == 3 || type == 9)
            return new Jumper(x, y, type);
        else if (type == 4 || type == 7)
            return new Strafer(x, y, type);
        else
            return new MapItem(x, y, type);
    }
}


class Jumper extends MapItem
{
    Jumper(int x, int y, int type)
    {
        super(x,y,type);
    }


    point pos(int time)
    {
        return new point(this.x, this.y - (int)Math.max(0., 50 * Math.sin(((double)time) * 2 * Math.PI / 30)));
    }
}


class Strafer extends MapItem
{
    Strafer(int x, int y, int type)
    {
        super(x,y,type);
    }
    point pos(int time)
    {
        return new point(this.x + (int)(50 *Math.sin(((double)time) * 2 * Math.PI / 30)), this.y);
    }
}




class ItemYComparator implements Comparator<MapItem>
{
    public int compare(MapItem a, MapItem b) {
        return a.getItemY() - b.getItemY();
  }


}


