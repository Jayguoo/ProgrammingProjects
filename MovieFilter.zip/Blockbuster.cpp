/***********https://www.onlinegdb.com/edit/gsaSL6MlL#_editor_6590553411*******************************************************************
Fall 2023 Programming Foundations I
Author: STUDENT NAME
Date: November ???, 2023
Purpose: Implement the Trainer class
*******************************************************************************/
#include "Blockbuster.h"

using namespace std;

Blockbuster::Blockbuster()
{
    currentIndex = 0;
    for (int i = 0; i < MAX_MOVIES; i++)
    {
        movies[i] = Movie();
    }
}




Blockbuster::Blockbuster(const Blockbuster & blockbuster)
{
    for(int i = 0; i < MAX_MOVIES; i++)
    {
        movies[i] = blockbuster.movies[i];
    }
    currentIndex = blockbuster.currentIndex;
}



Blockbuster::~Blockbuster()
{
    
}

//******************************************************************************

void Blockbuster::addMovie(const int rottenTomatoesScore, const float imdbRating, const string genre, const int year, const unsigned long worldwideBoxOffice, const string title)
{
    //Movie::Movie(const int yearIn, const float imdbRatingIn, const string titleIn, const int rottenTomateScoresIn, const unsigned long worldWideBoxOfficeIn, const string genreIn)
    //cout << "Hello";
    Movie movie(year, imdbRating, title, rottenTomatoesScore, worldwideBoxOffice,genre);
    movies[currentIndex] = movie;
    currentIndex++;
}


void Blockbuster::addMovie(const Movie movie)
{
    movies[currentIndex] = movie;
    currentIndex++;
}

//******************************************************************************

void Blockbuster::filterByGenre(const string genre) const
{
    int sum = 0;
    for (int i = 0; i < currentIndex; i++)
    {
        if (movies[i].getGenre() == genre)
        {
            movies[i].print(); 
            sum++;
        }
    }
    if (sum>0)
    {
        cout << "Found " << sum << " movies with genre "<< genre <<"\n\n";
    }
    else
    {
        cout << "Error: no movies found with genre " << genre << "\n\n";
    }
}

void Blockbuster::imdbTomatoRange(const float imdbMin, const float imdbMax, const int tomatoMin, const int tomatoMax) const
{
    int sum = 0;
    for (int i = 0; i < currentIndex; i++)
    {
        if (movies[i].getImdbRating() >= imdbMin && movies[i].getImdbRating() <= imdbMax && movies[i].getRottenTomateScores() >= tomatoMin && movies[i].getRottenTomateScores() <= tomatoMax)
        {
            movies[i].print(); 
            sum++;
        }
    }
    if (sum>0)
    {
        cout << "Found " << sum << " movies with an IMDB rating between " << imdbMin << " and " << imdbMax << " and a Rotten Tomatoes rating between " << tomatoMin <<" and " << tomatoMax << "\n\n";
    }
    else
    {
        cout << "Error: no movies found\n\n";
    }

}

Movie Blockbuster::highestGrossing() const
{
    Movie highestGrossingMovie = movies[0]; 
    for (int i = 1; i < currentIndex; i++)
    {
        if (movies[i].getWorldWideBoxOffice() > highestGrossingMovie.getWorldWideBoxOffice())
        {
            highestGrossingMovie = movies[i];
        }
    }
    cout << "Highest Grossing Movie: \n";
    highestGrossingMovie.print();
    return highestGrossingMovie;
}

//******************************************************************************

void Blockbuster::print() const
{
    int sum = 0;
    for (int i = 0; i < currentIndex; i++)
    {
        movies[i].print(); 
        sum++;
    }
    cout << "There are " << sum << " movies in total\n\n";
}







