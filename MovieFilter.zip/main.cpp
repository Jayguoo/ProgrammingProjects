/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include "Blockbuster.h"

// GIVEN - mostly given to you - you will need to modify this code to add the movie
// to the Blockbuster object instead of just printing the information to the screen
void read(string filename, Blockbuster & videoStore) {
	// Attempt to open specified file
	ifstream din(filename);

	// Check if file was opened successfully
	if (din.fail()) {
		cout << "Error opening file " << filename << endl;
		exit(1);
	}

	// Declare variables to read into
	int rottenTomatoesScore;
	float imdbRating;
	string genre;
	int year;
	// profits will be a positive number, so this is an unsigned long integer now
	// this fixes the overflow issue on some computers when just long is used
	unsigned long worldwideBoxOffice;
	string title;

	// Read in header line from file, throw away
	getline(din, title);

	// Read in all movies from file
	while (!din.eof()) {
		din >> rottenTomatoesScore >> imdbRating >> genre >> year >> worldwideBoxOffice;
		getline(din, title);

		// Remove first character of title (space)
		// Can use substr or erase
		// title = title.substr(1);
		title.erase(0, 1);

		// this is provided for error checking to make sure you are reading in the file of movies - 
		// after you know you are, you will comment this line out and just add the movie to the 
		// Blockbuster object array using a method found in the Blockbuster class
		// cout << year << " " << title << " " << rottenTomatoesScore << " " << imdbRating << " " << genre << " " << worldwideBoxOffice << endl;

		// Add movie to Blockbuster object array - you will be adding code here!!
		// you do NOT need to add code above this line
		//cout <<"Main";
		videoStore.addMovie(rottenTomatoesScore, imdbRating, genre, year, worldwideBoxOffice, title);
        

	}

	// Close input file
	din.close();
}



// GIVEN - Function to print menu to console
void printMenu() {
    
	cout << "1. Filter by genre" << endl;
	cout << "2. Filter by range of IMDB rating and Rotten Tomatoes score" << endl;
	cout << "3. Get the highest grossing movie" << endl;
	cout << "4. Print all movies" << endl;
	cout << "5. Exit" << endl;
}

// GIVEN - get the user's choice from the menu
int getUserChoice() {
	// Declare variable to store user choice, prompt for input, and store input
	int choice;
	cout << "Enter choice: ";
	cin >> choice;
	cout << endl;

	// Check if input is valid
	if (choice < 1 || choice > 5) {
		cout << "Invalid choice. Try again." << endl;
		return getUserChoice();
	}

	// Return user choice
	return choice;
}

int main() {

	// Create Blockbuster object using default constructor, call read function
	Blockbuster block;
	read("blockbuster.txt", block);
	bool keepGoing = true;
	int choice, tomatoMin, tomatoMax;
	float imdbMin, imdbMax;
	string genre;
	// Print menu and get user choice

	// while user's choice is not to quit
	while(keepGoing == true)
	{
	printMenu();
	    choice = getUserChoice();

		// switch statement between the options
        switch (choice) {
            case 1:
                cout << "Enter genre: ";
                cin >> genre;
                block.filterByGenre(genre);
                break;
            case 2:
                cout << "Enter minimum IMDB rating: ";
                cin >> imdbMin;
                cout << "Enter maximum IMDB rating: ";
                cin >> imdbMax;
                cout << "Enter minimum Rotten Tomatoes score: ";
                cin >> tomatoMin;
                cout << "Enter maximum Rotten Tomatoes score: ";
                cin >> tomatoMax;
                block.imdbTomatoRange(imdbMin, imdbMax, tomatoMin, tomatoMax);
                break;
            case 3:
                block.highestGrossing();
                break;
            case 4:
                block.print();
                break;
            case 5:
                keepGoing = false;
                break;
        }
    }


	
	// goodbye message
	cout << "Thank you for attempting to keep us in business!";

	return 0;
}
