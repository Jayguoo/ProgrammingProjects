#include "Movie.h"

Movie::Movie()
{
    imdbRating = 0.0;
    genre = "";
    title = "";
    year = 0;
    rottenTomateScores = 0;
    worldWideBoxOffice = 0;
}
Movie::Movie(const int yearIn, const float imdbRatingIn, const string titleIn, const int rottenTomateScoresIn, const unsigned long worldWideBoxOfficeIn, const string genreIn)
{
    imdbRating = imdbRatingIn;
    genre = genreIn;
    title = titleIn;
    year = yearIn;
    rottenTomateScores = rottenTomateScoresIn;
    worldWideBoxOffice = worldWideBoxOfficeIn;

}
Movie::Movie(const Movie &copy)
{
    imdbRating = copy.imdbRating;
    genre = copy.genre;
    title = copy.title;
    year = copy.year;
    rottenTomateScores = copy.rottenTomateScores;
    worldWideBoxOffice = copy.worldWideBoxOffice;
}
Movie::~Movie()
{
}

//******************************************************************************

void Movie::print() const
{
    cout<<"Imdb Rating: " << imdbRating<< "\n";
    cout<<"Genre: " << genre<< "\n";
    cout<<"Title: " << title<< "\n";
    cout<<"Year: " << year<< "\n";
    cout<<"Rotten Tomate Scores: " << rottenTomateScores<< "\n";
    cout<<"World Wide Box Office: " << worldWideBoxOffice<< "\n";
    cout<< "\n";

}



void Movie::setImdbRating(const float sImdbRating)
{
    imdbRating = sImdbRating;
}

void Movie::setGenre(const string sGenre)
{
    genre = sGenre;
}

void Movie::setTitle(const string sTitle)
{
    title = sTitle;
}

void Movie::setYear(const int sYear)
{
    year = sYear;
}

void Movie::setRottenTomateScores(const int sRottenTomateScores)
{
    rottenTomateScores = sRottenTomateScores;
}

void Movie::setWorldWideBoxOffice(const unsigned long sWorldWideBoxOffice)
{
    worldWideBoxOffice = sWorldWideBoxOffice;
}

//******************************************************************************


float Movie::getImdbRating() const
{
    return imdbRating;
}

string Movie::getGenre() const
{
    return genre;
}

string Movie::getTitle() const
{
    return title;
}

int Movie::getYear() const
{
    return year;
}

int Movie::getRottenTomateScores() const
{
    return rottenTomateScores;
}

unsigned long Movie::getWorldWideBoxOffice() const
{
    return worldWideBoxOffice;
}
