#include <string>
#include <cstdlib>
#include <time.h>
#include <iostream>
#include <fstream>

using namespace std;

class Movie
{
    public:
        Movie();
        Movie(const int yearIn, const float imdbRatingIn, const string titleIn, const int rottenTomateScoresIn, const unsigned long worldWideBoxOfficeIn, const string genreIn);
        Movie(const Movie &copy);
        ~Movie();
        
        void print() const;
        //NOTE TO SELVES: finish compare movies function!!
        //setters
        void setImdbRating(const float ImdbRating);
        void setGenre(const string Genre);
        void setTitle(const string Title);
        void setYear(const int Year);
        void setRottenTomateScores(const int RottenTomateScores);
        void setWorldWideBoxOffice(const unsigned long worldWideBoxOffice);
        
        //getters
        float getImdbRating() const;
        string getGenre() const;
        string getTitle() const;
        int getYear() const;
        int getRottenTomateScores() const;
        unsigned long getWorldWideBoxOffice() const;
        
    private:
        string genre, title; //, leadActor, director, style, plot, synopsis; <-- version 2.0
        int year, rottenTomateScores;
        float imdbRating;
        unsigned long worldWideBoxOffice;
};